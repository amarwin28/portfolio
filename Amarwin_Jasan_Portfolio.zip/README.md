# Amarwin Jasan — Portfolio Website

A minimal, premium personal portfolio website for **Amarwin Jasan**, Computer Science Engineering Student at Dhaanish Chennai College of Engineering, Founder of WEBOCLYPSE, and Media & Growth Head at Kromaxzon Technologies.

Engineered with clean dark-mode aesthetics featuring charcoal backgrounds, restrained warm gold accents, clear typography, and responsive navigation across desktop, tablet, and mobile.

---

## Technology Stack

- **Framework**: [React 19](https://react.dev/) + [TypeScript](https://www.typescriptlang.org/)
- **Build Tool**: [Vite 8](https://vitejs.dev/)
- **Styling**: [Tailwind CSS v4](https://tailwindcss.com/)
- **Icons**: [Lucide React](https://lucide.dev/) + Custom Brand SVG Icons
- **Typography**: Google Fonts — Plus Jakarta Sans, Outfit, Caveat

---

## Features

1. **Navigation**:
   - Desktop left sidebar navigation with quick profile links.
   - Sticky top bar with section links and resume download action.
   - Responsive mobile navigation bar and drawer.

2. **Hero Section**:
   - Clean typographical headline and role overview.
   - Direct action buttons (View Projects, Resume, Contact).
   - Understated academic and project metrics.
   - Portrait showcase in a clean, minimal frame.

3. **Companies & Startups**:
   - **WEBOCLYPSE** (Founder): Student technology and leadership initiative ([weboclypse.site](https://www.weboclypse.site/)).
   - **Kromaxzon Technologies** (Media & Growth Head): Scalable enterprise software and AI solutions ([kromaxzon.in](https://kromaxzon.in/)).
   - **codeVstudio** (Member): Digital product development studio and startup ([codevstudio.in](https://codevstudio.in/)).

4. **Featured Projects**:
   - **JAS Traders Website**: Commercial packaging business website ([Live Demo](https://jas-traders-23.vercel.app/))
   - **AJ Controller**: Android Bluetooth game controller app ([GitHub](https://github.com/amarwin28/AJ-CONTOLLER))
   - **JARVIS**: Cross-platform personal AI assistant ([Android Repo](https://github.com/amarwin28/JARVIS-ANDROID) / [Windows Repo](https://github.com/amarwin28/JARVIS-WINDOWS))
   - **LoanLens AI**: Machine learning credit risk assessment platform ([Live Demo](https://loanlens-ai-beta.vercel.app/))
   - **SkillGap AI**: Offline Java desktop resume skill-gap analyzer
   - **FeedGuard AI**: Collaborative feed quality classification platform ([Live Demo](https://feedguard.vercel.app/))
   - **DC Outpass**: Collaborative campus outpass management portal
   - **NanoSpark Web Designing**: Collaborative web design startup initiative

5. **Profile & Contact**:
   - **About**: Engineering focus, full-stack & mobile capabilities, and background.
   - **Skills**: Grouped programming languages, frameworks, APIs, and tooling.
   - **Experience & Education**: Timeline and academic milestones.
   - **Achievements & Certifications**: Technical certifications and awards.
   - **Contact**: Direct email (`amarwin2007@gmail.com`), phone (`+91 99945 96987`), location (`Kanyakumari, India`), GitHub, and LinkedIn.

---

## Development

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Run production build
npm run build

# Run linter
npm run lint
```
